# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Blog::Application.config.secret_key_base = '4f895aa5a18cbd30032633d934c3c61939a92202a1e5aa9eba688a254a8ae059ca515b13de54db6cc784f9ed88cf85bfbf9f742412ecd36324f84ab0808e9475'
